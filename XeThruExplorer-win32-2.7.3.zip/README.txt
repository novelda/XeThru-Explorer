XeThru Explorer 2



XeThru Explorer 2 for Windows allows for easy configuration of the connected XeThru radar sensor module. An intuitive user interface provides visualization of sensor data. Various logging and data storage features are available.



XeThru Explorer works with Windows 7 and Windows 10.



Note to X2M1000 Inspiration Module Users:

XeThru Explorer 2 does not have legacy support for X2M1000. Please use XeThru Explorer 1 (https://www.xethru.com/community/resources/xethru-explorer-for-windows-beta.5/download?version=21).

Note to First Time Windows 7 Users (not required for Windows 10):

The XeThru sensor modules may require USB drivers for Windows. There are two USB drivers, and both are needed. 
1. Run and install the bundled driver-atmel-bundle-7.0.888.exe


2. Copy bossa.inf and bossa.cat to your windows\inf folder 